package sg.edu.tp.musicstream;

public class Song
{
    private String id;
    private String title;
    private String artist;
    private String fileLink;
    private double songLength;
    private String coverArt;
    private String lyricsURL;

    //constructor
    public Song(String i, String t, String a, String f, double sl, String ca, String l)
    {
        id = i;
        title = t;
        artist = a;
        fileLink = f;
        songLength = sl;
        coverArt = ca;
        lyricsURL = l;
    }

    public String getId()
    {
        return id;
    }

    public void setId(String newId)
    {
        id = newId;
    }

    public String getTitle()
    {
        return title;
    }

    public void setTitle(String newTitle)
    {
        title = newTitle;
    }

    public String getArtist()
    {
        return artist;
    }

    public String getFileLink()
    {
        return fileLink;
    }

    public String getCoverArt()
    {
        return coverArt;
    }

    public double getSongLength() {
        return songLength;
    }

    public void setSongLength(double songLength) {
        this.songLength = songLength;
    }

    public String getLyricsURL() {
        return lyricsURL;
    }
}
