package sg.edu.tp.musicstream;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Filter;
import android.widget.Filterable;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class UsersAdapter extends RecyclerView.Adapter<UsersAdapter.UsersAdapterVh> implements Filterable
{
    private List<Model> ModelList;
    private List<Model> getModelListFiltered;
    private Context context;
    private SelectedUser selectedUser;

    public UsersAdapter(List<Model> modelList, SelectedUser selectedUser) {
        this.ModelList = modelList;
        this.getModelListFiltered = modelList;
        this.selectedUser = selectedUser;

    }

    @NonNull
    @Override
    public UsersAdapter.UsersAdapterVh onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        context = parent.getContext();
        return new UsersAdapterVh(LayoutInflater.from(context).inflate(R.layout.row_items, null));
    }

    @Override
    public void onBindViewHolder(@NonNull UsersAdapter.UsersAdapterVh holder, int position) {

        Model Model = ModelList.get(position);
        String name = Model.getName();

        holder.tvName.setText(name);

    }

    @Override
    public int getItemCount() {
        return ModelList.size();
    }

    @Override
    public Filter getFilter() {
        final Filter filter = new Filter() {
            @Override
            protected FilterResults performFiltering(CharSequence charSequence) {
                FilterResults filterResults = new FilterResults();

                if(charSequence == null | charSequence.length() == 0) {
                    filterResults.count = getModelListFiltered.size();
                    filterResults.values = getModelListFiltered;
                }else{
                    String searchChr = charSequence.toString().toLowerCase();

                    List<Model> resultData = new ArrayList<>();

                    for(Model model: getModelListFiltered)
                    {
                        if(model.getName().toLowerCase().contains(searchChr))
                        {
                            resultData.add(model);
                        }
                    }
                    filterResults.count = resultData.size();
                    filterResults.values = resultData;
                }
                return filterResults;
            }

            @Override
            protected void publishResults(CharSequence constraint, FilterResults filterResults) {

                ModelList = (List<Model>)filterResults.values;
                notifyDataSetChanged();
            }
        };
        return filter;
    }

    public interface SelectedUser{

        void selectedUser(Model model);
    }

    public class UsersAdapterVh extends RecyclerView.ViewHolder
    {
        TextView tvName;
        ImageView imIcon;
        public UsersAdapterVh(@NonNull View itemView)
        {
            super(itemView);
            tvName = itemView.findViewById(R.id.name);
            imIcon = itemView.findViewById(R.id.arrow);

            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    selectedUser.selectedUser(ModelList.get(getAdapterPosition()));
                }
            });
        }
    }
}
