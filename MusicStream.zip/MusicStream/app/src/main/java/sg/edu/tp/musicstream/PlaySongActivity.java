package sg.edu.tp.musicstream;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;

import android.media.AudioManager;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;


import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;


import sg.edu.tp.musicstream.util.AppUtil;

public class PlaySongActivity extends AppCompatActivity {
    //this is the website URL to stream the music
    private static final String BASE_URL = "https://p.scdn.co/mp3-preview/";
    private static final String BASE_URL2 = "https://www.azlyrics.com/lyrics/";
    static ArrayList<Song> songmenu = new ArrayList<Song>();

    //These variables are the song information
    private String songId = "";
    private String title = "";
    private String artist = "";
    private String fileLink = "";
    private String coverArt = "";
    private String url = "";
    private String lyrics = "";
    private String lyricsURL = "";

    //This is the build-in MusicPlayer object to play the music
    private MediaPlayer player = null;

    //This is the position if the song in the playback, we set it to 0 here so that it starts at the beginning
    private int musicPosition = 0;

    //The button variable is created to link the Play/Pause button
    private Button btnPlayPause = null;

    SeekBar seekbar;
    Handler handler = new Handler();

    Button b1;
    Button replayBtn;
    Button shuffleBtn;
    Button likeBtn;
    Boolean replayFlag = false;
    Boolean shuffleFlag = false;
    Boolean likeFlag = false;

    //Create a SongCollection object
    SongCollection songCollection = new SongCollection();
    SongCollection originalsongCollection = new SongCollection();

    List<Song> shuffleList = Arrays.asList(songCollection.songs);
    private long delayMillis;

    static Song selectedSong;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_play_song);

        //retrieve the Play/Pause button
        btnPlayPause = (Button)findViewById(R.id.btnPlayPause);

        //retrieve the Song data from the Intent object
        retrieveData();

        //display the Song information on the Playback screen
        displaySong(title, artist, coverArt);

        seekbar = findViewById(R.id.seekBar);
        seekbar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {

            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar)
            {
                if (player !=null && player.isPlaying())
                {
                    player.seekTo(seekBar.getProgress());
                }

            }
        });



        replayBtn = findViewById(R.id.btnReplay);
        shuffleBtn = findViewById(R.id.btnShuffle);
        likeBtn = findViewById(R.id.likeSonglogo);
    }

    Runnable p_bar = new Runnable()
    {
        @Override
        public void run() {
            if (player !=null && player.isPlaying())
            {
                seekbar.setProgress(player.getCurrentPosition());
            }

            handler.postDelayed(p_bar, delayMillis);
        }
    };


    private void retrieveData()
    {
        Bundle songData = this.getIntent().getExtras();

        songId = songData.getString("id");
        title = songData.getString("title");
        artist = songData.getString("artist");
        fileLink = songData.getString("fileLink");
        coverArt = songData.getString("coverArt");
        lyricsURL = songData.getString("lyricsURL");

        url = BASE_URL + fileLink;
        lyrics = BASE_URL2 + lyricsURL;
    }

    //method displaySong
    private void displaySong(String title, String artist, String coverArt)
    {
        //find the Song title TextView from the screen
        TextView txtTitle = (TextView)findViewById(R.id.txtSongTitle);

        //set the text of the TextView to the selected song title
        txtTitle.setText(title);

        //find the Song artist TextView from the screen
        TextView txtArtist = (TextView)findViewById(R.id.txtArtist);

        //set the text of the TextView to the selected song artist
        txtArtist.setText(artist);

        //find the Song image ImageView from the screen and set the image accordingly
        int imageId = AppUtil.getImageIdFromDrawable(this, coverArt);
        ImageView ivCoverArt = (ImageView)findViewById(R.id.imgCoverArt);
        ivCoverArt.setImageResource(imageId);

    }

    private void preparePlayer()
    {
        player = new MediaPlayer();

        try
        {
            player.setAudioStreamType(AudioManager.STREAM_MUSIC);
            player.setDataSource(url);  //indicate the url of the song to the player
            player.prepare();
        }
        catch(IOException e)
        {
            e.printStackTrace();
        }
    }

    public void playOrPauseMusic(View view)
    {
        if (player == null) //first time invoke the player object
            preparePlayer();

        if (!player.isPlaying()) //when play the music
        {
            if (musicPosition > 0)
            {
                player.seekTo(musicPosition);
            }

            player.start();
            seekbar.setMax(player.getDuration());
            handler.removeCallbacks(p_bar);
            handler.postDelayed(p_bar, delayMillis);
            gracefullyStopWhenMusicEnds();
            btnPlayPause.setBackgroundResource(R.drawable.ic_pause);

            setTitle("Now Playing: " + title + " - " + artist);


        }
        else //when pause the music
        {
            pauseMusic();
        }
    }

    private void pauseMusic()
    {
        player.pause();

        btnPlayPause.setBackgroundResource(R.drawable.ic_play_arrow);

        musicPosition = player.getCurrentPosition();

    }

    private void gracefullyStopWhenMusicEnds()
    {
        player.setOnCompletionListener(new MediaPlayer.OnCompletionListener()
        {
            public void onCompletion(MediaPlayer mediaPlayer)
            {
                if(replayFlag)
                {
                    playOrPauseMusic(null);
                }
                else {
                    btnPlayPause.setBackgroundResource(R.drawable.ic_play_arrow);
                    stopActivities();
                }
            }
        });
    }

    public void stopActivities()
    {
        if(player != null)  //player is playing/pausing music
        {
            btnPlayPause.setBackgroundResource(R.drawable.ic_play_arrow);
            handler.removeCallbacks(p_bar);
            musicPosition = 0;
            setTitle(" ");
            player.stop();
            player.release();
            player = null;
        }

    }

    //method playNext
    public void playNext(View view)
    {
        Song nextSong = songCollection.getNextSong(songId);//getting the next song
        Song nextSong2 = songCollection.getNextSong2(songId);
        Song nextSong3 = songCollection.getNextSong3(songId);

        if (nextSong != null)
        {
            songId = nextSong.getId();
            title = nextSong.getTitle();
            artist = nextSong.getArtist();
            fileLink = nextSong.getFileLink();
            coverArt = nextSong.getCoverArt();
            lyricsURL = nextSong.getLyricsURL();

            url = BASE_URL + fileLink; //next song url
            lyrics = BASE_URL2 + lyricsURL;

            displaySong(title, artist, coverArt);
            stopActivities();
            playOrPauseMusic(view);
        }

        if (nextSong2 != null)
        {
            songId = nextSong2.getId();
            title = nextSong2.getTitle();
            artist = nextSong2.getArtist();
            fileLink = nextSong2.getFileLink();
            coverArt = nextSong2.getCoverArt();
            lyricsURL = nextSong2.getLyricsURL();

            url = BASE_URL + fileLink; //next song url
            lyrics = BASE_URL2 + lyricsURL;

            displaySong(title, artist, coverArt);
            stopActivities();
            playOrPauseMusic(view);
        }

        if (nextSong3 != null)
        {
            songId = nextSong3.getId();
            title = nextSong3.getTitle();
            artist = nextSong3.getArtist();
            fileLink = nextSong3.getFileLink();
            coverArt = nextSong3.getCoverArt();
            lyricsURL = nextSong3.getLyricsURL();

            url = BASE_URL + fileLink; //next song url
            lyrics = BASE_URL2 + lyricsURL;

            displaySong(title, artist, coverArt);
            stopActivities();
            playOrPauseMusic(view);
        }
    }

    //method playPrevious
    public void playPrevious(View view)
    {
        Song prevSong = songCollection.getPrevSong(songId);
        Song prevSong2 = songCollection.getPrevSong2(songId);
        Song prevSong3 = songCollection.getPrevSong3(songId);

        if (prevSong != null)
        {
            songId = prevSong.getId();
            title = prevSong.getTitle();
            artist = prevSong.getArtist();
            fileLink = prevSong.getFileLink();
            coverArt = prevSong.getCoverArt();
            lyricsURL = prevSong.getLyricsURL();

            url = BASE_URL + fileLink; //prev song url
            lyrics = BASE_URL2 + lyricsURL;

            displaySong(title, artist, coverArt);
            stopActivities();
            playOrPauseMusic(view);
        }

        if (prevSong2 != null)
        {
            songId = prevSong2.getId();
            title = prevSong2.getTitle();
            artist = prevSong2.getArtist();
            fileLink = prevSong2.getFileLink();
            coverArt = prevSong2.getCoverArt();
            lyricsURL = prevSong2.getLyricsURL();

            url = BASE_URL + fileLink; //prev song url
            lyrics = BASE_URL2 + lyricsURL;

            displaySong(title, artist, coverArt);
            stopActivities();
            playOrPauseMusic(view);
        }

        if (prevSong3 != null)
        {
            songId = prevSong3.getId();
            title = prevSong3.getTitle();
            artist = prevSong3.getArtist();
            fileLink = prevSong3.getFileLink();
            coverArt = prevSong3.getCoverArt();
            lyricsURL = prevSong3.getLyricsURL();

            url = BASE_URL + fileLink; //prev song url
            lyrics = BASE_URL2 + lyricsURL;

            displaySong(title, artist, coverArt);
            stopActivities();
            playOrPauseMusic(view);
        }
    }
    public void playReplay(View view)
    {
        if (replayFlag)
        {
            replayBtn.setBackgroundResource(R.drawable.ic_replay_off);
        }
        else
            {
                replayBtn.setBackgroundResource(R.drawable.ic_replay_on);
            }

        replayFlag = !replayFlag;
    }

    public void playShuffle(View view)
    {
        if (shuffleFlag)
        {
            shuffleBtn.setBackgroundResource(R.drawable.ic_shuffle_off);
            songCollection = new SongCollection();
        } else
        {
            shuffleBtn.setBackgroundResource(R.drawable.ic_shuffle_on);
            Collections.shuffle(shuffleList);
            shuffleList.toArray(songCollection.songs);
        }

        shuffleFlag = !shuffleFlag;
    }


    public void playLyrics (View view)
    {
        Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(lyrics));
        startActivity(intent);
    }

    public void goback (View view)
    {
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
    }

    public void gotosongmenu (View view)
    {
        Intent intent = new Intent(this, SongMenuActivity.class);
        startActivity(intent);
    }

    public void likesong (View view)
    {
        if(likeFlag)
        {
            likeBtn.setBackgroundResource(R.drawable.ic_likesong);
        }

        else
            {
                likeBtn.setBackgroundResource(R.drawable.ic_likesong_filled);
                Toast.makeText(PlaySongActivity.this, "Liked Song", Toast.LENGTH_SHORT).show();
            }

        likeFlag = !likeFlag;
    }

    public void gobackhome (View view)
    {
        Intent intent = new Intent(this, MainInterfaceActivity.class);
        startActivity(intent);
    }


}
