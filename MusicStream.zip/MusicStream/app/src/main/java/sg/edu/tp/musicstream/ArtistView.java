package sg.edu.tp.musicstream;

import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class ArtistView extends RecyclerView.ViewHolder
{
    public TextView Artist;
    public ImageView image2;
    public Button removeBtn2;

    public ArtistView(@NonNull View itemView)
    {

        super(itemView);

        Artist = itemView.findViewById(R.id.artistname);
        image2 = itemView.findViewById(R.id.imageView111);
        removeBtn2 = itemView.findViewById(R.id.removebtn2);
    }
}
