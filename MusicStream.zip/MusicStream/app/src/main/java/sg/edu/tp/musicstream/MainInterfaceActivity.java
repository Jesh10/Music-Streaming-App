package sg.edu.tp.musicstream;


import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;

import android.view.View;


public class MainInterfaceActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_interface);

    }
    public void gomain (View view)
    {
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
    }

    public void gotoprofile (View view)
    {
        Intent intent = new Intent(this, ProfileActivity.class);
        startActivity(intent);
    }

    public void gototophits (View view)
    {
        Intent intent = new Intent(this, TopHitsActivity.class);
        startActivity(intent);
    }

    public void gotosearch (View view)
    {
        Intent intent = new Intent(this, SearchActivity.class);
        startActivity(intent);
    }

    public void gotoplaylists(View view)
    {
        Intent intent = new Intent(this, PlaylistActivity.class);
        startActivity(intent);
    }

    public void gotomyartist(View view)
    {
        Intent intent = new Intent(this, MyArtistActivity.class);
        startActivity(intent);
    }
}