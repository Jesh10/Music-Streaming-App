package sg.edu.tp.musicstream;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

import sg.edu.tp.musicstream.util.AppUtil;

public class PlaylistAdapter extends RecyclerView.Adapter<PlaylistView> {
    public List<Playlist> playlists;
    Context context;

    public PlaylistAdapter(List<Playlist> playlists) {
        this.playlists = playlists;
    }


    @NonNull
    @Override
    public PlaylistView onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        context = parent.getContext();
        return new PlaylistView(LayoutInflater.from(context).inflate(R.layout.playlist_items, parent, false));
    }

    @Override
    public void onBindViewHolder(@NonNull PlaylistView holder, int position) {

        Playlist playlist = playlists.get(position);
        TextView playlistname = holder.playlist;
        playlistname.setText(playlist.getPlaylist());
        int imageid = AppUtil.getImageIdFromDrawable(context, playlist.getCoverArt());
        holder.image3.setImageResource(imageid);
        int imageid2 = AppUtil.getImageIdFromDrawable(context, playlist.getArrow());
        holder.image4.setImageResource(imageid2);
    }

    @Override
    public int getItemCount() {
        return playlists.size();
    }
}
