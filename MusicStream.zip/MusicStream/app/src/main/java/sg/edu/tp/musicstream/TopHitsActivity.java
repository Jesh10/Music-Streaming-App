package sg.edu.tp.musicstream;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Toast;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.util.ArrayList;

import sg.edu.tp.musicstream.util.AppUtil;

public class TopHitsActivity extends AppCompatActivity {

    private SongCollection songCollection = new SongCollection();
    static ArrayList<Song> myList = new ArrayList<Song>();
    SharedPreferences sharedPreferences;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_top_hits);

        sharedPreferences = getSharedPreferences("My Songs", MODE_PRIVATE);
        String albums = sharedPreferences.getString("list","");
        if(albums.equals(""))
        {
            TypeToken<ArrayList<Song>> token = new TypeToken<ArrayList<Song>>(){};
            Gson gson = new Gson();
            myList = gson.fromJson(albums, token.getType());
        }
    }

    public void handleSelection(View view)
    {
        //1. Get the ID of the selected song
        String resourceId = AppUtil.getResourceId(this, view);

        //2. Search for the selected song based on the ID so that all information/data of the song can be retrieved from a song list
        Song selectedSong = songCollection.searchById2(resourceId);

        //3. Popup a message on the screen to show the title of the song
        AppUtil.popMessage(this, "Streaming song: " + selectedSong.getTitle());

        // 4. Send the song data to the player screen to be played
        sendDataToActivity(selectedSong);
    }

    public void sendDataToActivity(Song song)
    {
        Intent intent = new Intent(this, PlaySongActivity.class);
        intent.putExtra("id", song.getId());
        intent.putExtra("title", song.getTitle());
        intent.putExtra("artist", song.getArtist());
        intent.putExtra("fileLink", song.getFileLink());
        intent.putExtra("coverArt", song.getCoverArt());

        startActivity(intent);
    }

    public void addToPlaylist(View view) {

        String songID = view.getContentDescription().toString();
        Song song = songCollection.searchById2(songID);
        myList.add(song);
        Gson gson = new Gson();
        String json = gson.toJson(myList);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString("list",json);
        editor.apply();
        Log.d("gson", json);

        Toast.makeText(this, "Added to My Songs", Toast.LENGTH_SHORT).show();
    }


    public void gobackhome (View view)
    {
        Intent intent = new Intent(this, MainInterfaceActivity.class);
        startActivity(intent);
    }

}