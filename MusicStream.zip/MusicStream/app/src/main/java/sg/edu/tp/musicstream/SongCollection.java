package sg.edu.tp.musicstream;

public class SongCollection {
    public Song[] songs = new Song[4];
    public Song[] hitsongs = new Song[4];
    public Song[] edsongs = new Song[3];

    //constructor
    public SongCollection() {
        prepareSongs();
    }


    //method prepareSongs
    private void prepareSongs()
    {
        //create Song object called TheWayYouLookTonight
        Song Grenade = new Song(
                "S1001",
                "Grenade",
                "Bruno Mars",
                "d6fc23418ef4a090922decfe6a47c7bc87c1d762?cid=2afe87a64b0042dabf51f37318616965",
                3.72,
                "grenade",
                "brunomars/grenade.html");

        //create Song object called BillieJean
        Song BillieJean = new Song(
                "S1002",
                "Neon",
                "John Mayer",
                "fc99e438c5bda5c4d2dd9e224e0cf288f9697091?cid=2afe87a64b0042dabf51f37318616965",
                4.37,
                "neon",
                "johnmayer/neon.html");

        Song Photograph = new Song(
                "S1003",
                "Photograph",
                "Ed Sheeran",
                "097c7b735ceb410943cbd507a6e1dfda272fd8a8?cid=2afe87a64b0042dabf51f37318616965",
                4.32,
                "photograph",
                "edsheeran/photograph.html");

        Song HymnForTheWeekend = new Song(
                "S1004",
                "Hymn for the Weekend",
                "Coldplay",
                "0e36103f9c968a7f07d502003a109c314f36ae9c?cid=2afe87a64b0042dabf51f37318616965",
                4.31,
                "hymn_for_the_weekend",
                "coldplay/hymnfortheweekend.html");


        //store Song objects into array
        songs[0] = Grenade;
        songs[1] = BillieJean;
        songs[2] = Photograph;
        songs[3] = HymnForTheWeekend;

    }

    {
        Song Paradise = new Song(
                "S1005",
                "Paradise",
                "Coldplay",
                "99475c9d11e4df26ca9d1460fbe0654e687d79e0?cid=2afe87a64b0042dabf51f37318616965",
                4.65,
                "paradise",
                "coldplay/paradise.html");

        Song OnecallAway = new Song(
                "S1006",
                "One Call Away",
                "Charlie Puth",
                "0c4bed645d246486c6b16fe0ac48d418259edecf?cid=2afe87a64b0042dabf51f37318616965",
                3.24,
                "onecallaway",
                "charlieputh/onecallaway.html");

        Song Havana = new Song(
                "S1007",
                "Havana",
                "Camilia Cabello",
                "663b794c2fc8da8f9bbe33698cb1bac567126a23?cid=2afe87a64b0042dabf51f37318616965",
                3.62,
                "camilia",
                "camilacabello/havana.html");

        Song Hello = new Song(
                "S1008",
                "Hello",
                "Adele",
                "4ab65f9b193ccc37f2059344322462ae5e9dac90?cid=2afe87a64b0042dabf51f37318616965",
                4.93,
                "adele",
                "adele/hello.html");

        hitsongs[0] = Paradise;
        hitsongs[1] = OnecallAway;
        hitsongs[2] = Havana;
        hitsongs[3] = Hello;
    }

    {
        Song Perfect = new Song(
                "S3001",
                "Perfect",
                "Ed Sheeran",
                "9779493d90a47f29e4257aa45bc6146d1ee9cb26?cid=2afe87a64b0042dabf51f37318616965",
                4.39,
                "perfect",
                "edsheeran/perfect.html");

        Song ShapeOfYou = new Song(
                "S3002",
                "Shape Of You",
                "Ed Sheeran",
                "84462d8e1e4d0f9e5ccd06f0da390f65843774a2?cid=2afe87a64b0042dabf51f37318616965",
                3.90,
                "shape_of_you",
                "edsheeran/shapeofyou.html");

        Song Photograph = new Song(
                "S3003",
                "Photograph",
                "Ed Sheeran",
                "097c7b735ceb410943cbd507a6e1dfda272fd8a8?cid=2afe87a64b0042dabf51f37318616965",
                4.32,
                "photograph",
                "edsheeran/photograph.html");

        edsongs[0] = Perfect;
        edsongs[1] = ShapeOfYou;
        edsongs[2] = Photograph;

    }

    //method searchById
    public Song searchById(String id)
    {
        //1. create a temporary Song object called s and set it to nul
        // Create Song object, null means empty object
        Song s = null;

        //2.searching
        for (int i = 0; i < songs.length; i++)
        {
            //take out current song
            s = songs[i];

            if (s.getId().equals(id))
            {
                return s;
            }
        }

        return null;
    }

    public Song searchById2(String id)
    {
        //1. create a temporary Song object called s and set it to nul
        // Create Song object, null means empty object
        Song s = null;

        //2.searching
        for (int i = 0; i < hitsongs.length; i++)
        {
            //take out current song
            s = hitsongs[i];

            if (s.getId().equals(id))
            {
                return s;
            }
        }

        return null;
    }

    public Song searchById3(String id)
    {
        //1. create a temporary Song object called s and set it to nul
        // Create Song object, null means empty object
        Song s = null;

        //2.searching
        for (int i = 0; i < edsongs.length; i++)
        {
            //take out current song
            s = edsongs[i];

            if (s.getId().equals(id))
            {
                return s;
            }
        }

        return null;
    }


    //method getNextSong
    public Song getNextSong(String currentsongId)
    {
        Song song = null;

        //traverse the array
        for(int index = 0; index < songs.length; index++)
        {
            if(songs[index].getId().equals(currentsongId) && (index < songs.length - 1))
            {
                song = songs[index + 1]; //get the next song and store it into "song" object
                break; // break out of the for loop
            }
        }

        return song;
    }

    public Song getNextSong2(String currentsongId)
    {
        Song song = null;

        //traverse the array
        for(int index = 0; index < hitsongs.length; index++)
        {
            if(hitsongs[index].getId().equals(currentsongId) && (index < hitsongs.length - 1))
            {
                song = hitsongs[index + 1]; //get the next song and store it into "song" object
                break; // break out of the for loop
            }
        }

        return song;
    }

    public Song getNextSong3(String currentsongId)
    {
        Song song = null;

        //traverse the array
        for(int index = 0; index < edsongs.length; index++)
        {
            if(edsongs[index].getId().equals(currentsongId) && (index < edsongs.length - 1))
            {
                song = edsongs[index + 1]; //get the next song and store it into "song" object
                break; // break out of the for loop
            }
        }

        return song;
    }

    //method getPrevSong
    public Song getPrevSong(String currentsongId)
    {
        Song song = null;

        //traverse the array
        for(int index = 0; index < songs.length; index++)
        {
            if(songs[index].getId().equals(currentsongId) && (index > 0 ))
            {
                song = songs[index - 1]; 
                break; // break out of the for loop
            }
        }

        return song;
    }

    public Song getPrevSong2(String currentsongId)
    {
        Song song = null;

        //traverse the array
        for(int index = 0; index < hitsongs.length; index++)
        {
            if(hitsongs[index].getId().equals(currentsongId) && (index > 0 ))
            {
                song = hitsongs[index - 1];
                break; // break out of the for loop
            }
        }

        return song;
    }

    public Song getPrevSong3(String currentsongId)
    {
        Song song = null;

        //traverse the array
        for(int index = 0; index < edsongs.length; index++)
        {
            if(edsongs[index].getId().equals(currentsongId) && (index > 0 ))
            {
                song = edsongs[index - 1];
                break; // break out of the for loop
            }
        }

        return song;
    }

}