package sg.edu.tp.musicstream;

public class Artist {
    private String id;
    private String artist;
    private String coverArt;

    public Artist(String i, String a, String ca) {
        this.id = i;
        this.artist = a;
        this.coverArt = ca;
    }

    public String getId()
    {
        return id;
    }

    public void setId(String newId)
    {
        id = newId;
    }

    public String getArtist()
    {
        return artist;
    }

    public String getCoverArt()
    {
        return coverArt;
    }
}

