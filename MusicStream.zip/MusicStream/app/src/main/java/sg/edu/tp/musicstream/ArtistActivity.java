package sg.edu.tp.musicstream;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Toast;

import com.google.gson.Gson;

import java.util.ArrayList;

import sg.edu.tp.musicstream.util.AppUtil;

public class ArtistActivity extends AppCompatActivity
{

    private ArtistCollection artistCollection = new ArtistCollection();
    static ArrayList<Artist> artistList = new ArrayList<Artist>();
    private SongCollection songCollection = new SongCollection();
    static ArrayList<Song> myList = new ArrayList<Song>();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_artist);

        Intent intent = getIntent();

        if(intent.getExtras() != null){
            Model model = (Model) intent.getSerializableExtra("data");
        }
    }

    public void handleSelection(View view)
    {
        //1. Get the ID of the selected song
        String resourceId = AppUtil.getResourceId(this, view);

        //2. Search for the selected song based on the ID so that all information/data of the song can be retrieved from a song list
        Song selectedSong = songCollection.searchById3(resourceId);

        //3. Popup a message on the screen to show the title of the song
        AppUtil.popMessage(this, "Streaming song: " + selectedSong.getTitle());

        // 4. Send the song data to the player screen to be played
        sendDataToActivity(selectedSong);
    }

    public void sendDataToActivity(Song song)
    {
        Intent intent = new Intent(this, PlaySongActivity.class);
        intent.putExtra("id", song.getId());
        intent.putExtra("title", song.getTitle());
        intent.putExtra("artist", song.getArtist());
        intent.putExtra("fileLink", song.getFileLink());
        intent.putExtra("coverArt", song.getCoverArt());
        intent.putExtra("lyricsURL", song.getLyricsURL());

        startActivity(intent);
    }

    public void playVideo (View view)
    {
        Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/watch?v=2Vv-BfVoq4g"));
        startActivity(intent);
    }

    public void gobacksearch (View view)
    {
        Intent intent = new Intent(this, SearchActivity.class);
        startActivity(intent);
    }

    public void addtoArtists(View view) {

        String artistID = view.getContentDescription().toString();
        Artist artist = artistCollection.searchById2(artistID);
        artistList.add(artist);
        Toast.makeText(this, "Added to My Artists", Toast.LENGTH_SHORT).show();
    }

    public void addToPlaylist(View view) {

        String songID = view.getContentDescription().toString();
        Song song = songCollection.searchById3(songID);
        myList.add(song);


        Toast.makeText(this, "Added to My Songs", Toast.LENGTH_SHORT).show();
    }
}