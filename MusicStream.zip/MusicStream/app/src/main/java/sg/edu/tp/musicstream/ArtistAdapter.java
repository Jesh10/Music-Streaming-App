package sg.edu.tp.musicstream;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

import sg.edu.tp.musicstream.util.AppUtil;

public class ArtistAdapter extends RecyclerView.Adapter<ArtistView>
{
    public List<Artist> artists;
    Context context;

    public ArtistAdapter(List<Artist>artists)
    {
        this.artists = artists;
    }


    @NonNull
    @Override
    public ArtistView onCreateViewHolder(@NonNull ViewGroup parent, int viewType)
    {
        context = parent.getContext();
        return new ArtistView(LayoutInflater.from(context).inflate(R.layout.artist_items,parent,false));
    }

    @Override
    public void onBindViewHolder(@NonNull ArtistView holder, final int position)
    {
        Artist artist = artists.get(position);
        TextView artistname = holder.Artist;
        artistname.setText(artist.getArtist());
        int imageid = AppUtil.getImageIdFromDrawable(context, artist.getCoverArt());
        holder.image2.setImageResource(imageid);
        holder.removeBtn2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ArtistActivity.artistList.remove(position);
                notifyDataSetChanged();
            }
        });

    }

    @Override
    public int getItemCount() {
        return artists.size();
    }

}
