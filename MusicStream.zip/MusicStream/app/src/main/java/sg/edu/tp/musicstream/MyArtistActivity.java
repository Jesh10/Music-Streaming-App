package sg.edu.tp.musicstream;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class MyArtistActivity extends AppCompatActivity implements UsersAdapter.SelectedUser{

    RecyclerView myartistList;
    ArtistAdapter artistAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_artist);

        myartistList = findViewById(R.id.recycleview2);
        artistAdapter = new ArtistAdapter(ArtistActivity.artistList);
        myartistList.setAdapter(artistAdapter);
        myartistList.setLayoutManager(new LinearLayoutManager(this));

    }

    public void gobackhome(View view)
    {
        Intent intent = new Intent(this, MainInterfaceActivity.class);
        startActivity(intent);
    }

    public void gobacksearch(View view)
    {
        Intent intent = new Intent(this, SearchActivity.class);
        startActivity(intent);
    }

    @Override
    public void selectedUser(Model model) {
        startActivity(new Intent(MyArtistActivity.this, ArtistActivity.class).putExtra("data", model));
    }
}