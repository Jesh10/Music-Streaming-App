package sg.edu.tp.musicstream;

public class Playlist
{
    private String id;
    private String playlist;
    private String coverArt;
    private String arrow;

    public Playlist(String i, String p, String ca, String a) {
        this.id = i;
        this.playlist = p;
        this.coverArt = ca;
        this.arrow = a;
    }

    public String getId()
    {
        return id;
    }

    public void setId(String newId)
    {
        id = newId;
    }

    public String getPlaylist()
    {
        return playlist;
    }

    public String getCoverArt()
    {
        return coverArt;
    }

    public String getArrow() {
        return arrow;
    }

}
