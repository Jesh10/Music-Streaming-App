package sg.edu.tp.musicstream;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class MySongsActivity extends AppCompatActivity
{

RecyclerView mysongsList;
SongAdapter songAdapter;
TopHitsAdapter topHitsAdapter;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_songs);

        mysongsList = findViewById(R.id.recycle);
        songAdapter = new SongAdapter(MainActivity.myList);
        topHitsAdapter = new TopHitsAdapter(TopHitsActivity.myList);
        mysongsList.setAdapter(songAdapter);
        mysongsList.setAdapter(topHitsAdapter);
        mysongsList.setLayoutManager(new LinearLayoutManager(this));

    }

    public void gobackplaylists(View view) {
        Intent intent = new Intent(this, PlaylistActivity.class);
        startActivity(intent);
    }
}