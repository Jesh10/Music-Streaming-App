package sg.edu.tp.musicstream;

public class ArtistCollection {

    public Artist[] artists = new Artist[6];

    public ArtistCollection() {
        prepareArtist();
    }

    private void prepareArtist()
    {
        //create Song object called TheWayYouLookTonight
        Artist EdSheeran = new Artist(
                "S2001",
                "Ed Sheeran",
                "ed_sheeran");

        //store Song objects into array
        artists[0] = EdSheeran;
    }

    public Artist searchById2(String id)
    {

        Artist a = null;

        for (int i = 0; i < artists.length; i++)
        {
            //take out current song
            a = artists[i];

            if (a.getId().equals(id))
            {
                return a;
            }
        }

        return null;
    }
}
