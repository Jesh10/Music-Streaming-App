package sg.edu.tp.musicstream;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import sg.edu.tp.musicstream.util.AppUtil;

public class SongMenuActivity extends AppCompatActivity
{
    private static final String BASE_URL = "https://p.scdn.co/mp3-preview/";

    private String songId = "";
    private String title = "";
    private String artist = "";
    private String fileLink = "";
    private String coverArt = "";
    private String url = "";

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_song_menu);

        retrieveData();

        displaySong(title, artist, coverArt);
    }

    private void retrieveData()
    {

        songId = PlaySongActivity.selectedSong.getId();
        title = PlaySongActivity.selectedSong.getTitle();
        artist = PlaySongActivity.selectedSong.getArtist();
        fileLink = PlaySongActivity.selectedSong.getFileLink();
        coverArt = PlaySongActivity.selectedSong.getCoverArt();

        url = BASE_URL + fileLink;
    }

    //method displaySong
    private void displaySong(String title, String artist, String coverArt)
    {
        //find the Song title TextView from the screen
        TextView txtTitle = (TextView)findViewById(R.id.txtSongTitle);

        //set the text of the TextView to the selected song title
        txtTitle.setText(title);

        //find the Song artist TextView from the screen
        TextView txtArtist = (TextView)findViewById(R.id.txtArtist);

        //set the text of the TextView to the selected song artist
        txtArtist.setText(artist);

        //find the Song image ImageView from the screen and set the image accordingly
        int imageId = AppUtil.getImageIdFromDrawable(this, coverArt);
        ImageView ivCoverArt = (ImageView)findViewById(R.id.imgCoverArt);
        ivCoverArt.setImageResource(imageId);

    }

    public void gobacktosong (View view)
    {
        Intent intent = new Intent(this, PlaySongActivity.class);
        startActivity(intent);
    }

}
