package sg.edu.tp.musicstream;

public class PlaylistCollection
{
    public Playlist[] playlists = new Playlist[2];

    public PlaylistCollection()
    {
        preparePlaylist();
    }

    private void preparePlaylist()
    {
        Playlist NewPlaylist = new Playlist(
                "linkplaylist",
                "New Playlist",
                "mysongs",
                "ic_baseline_navigate_next_24"
        );

        playlists[0] = NewPlaylist;
    }

    public Playlist searchById3(String id)
    {
        Playlist p = null;

        for (int i = 0; i < playlists.length; i++)
        {
            p = playlists[i];

            if(p.getId().equals(id))
            {
                return p;
            }
        }

        return null;
    }
}
