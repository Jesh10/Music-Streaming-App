package sg.edu.tp.musicstream;

import android.provider.ContactsContract;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

public class PlaylistView extends RecyclerView.ViewHolder
{

    public ImageView image3;
    public ImageView image4;
    public TextView playlist;

    public PlaylistView(View itemView)
    {
        super(itemView);

        image3 = itemView.findViewById(R.id.playlistimg);
        image4 = itemView.findViewById(R.id.nextarrow);
        playlist = itemView.findViewById(R.id.nameplaylist);
    }
}
