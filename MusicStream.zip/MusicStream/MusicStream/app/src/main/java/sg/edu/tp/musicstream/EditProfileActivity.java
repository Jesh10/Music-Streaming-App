package sg.edu.tp.musicstream;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import sg.edu.tp.musicstream.util.AppUtil;

public class EditProfileActivity extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_profile);

    }

    public void gobacktoprofile (View view)
    {
        Intent intent = new Intent(this, ProfileActivity.class);
        startActivity(intent);
    }


    public void doedit (View view)
    {
        EditText editText = findViewById(R.id.editText);
        String message = editText.getText().toString();

        Intent intent = new Intent(this, ProfileActivity.class);
        intent.putExtra("Extra",message);
        startActivity(intent);
    }
}