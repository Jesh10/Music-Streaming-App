package sg.edu.tp.musicstream;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.Toast;

import java.util.ArrayList;

public class PlaylistActivity extends AppCompatActivity
{
    private PlaylistCollection playlistCollection = new PlaylistCollection();
    static ArrayList<Playlist> mplaylistlist = new ArrayList<>();

    //ArrayList<Playlists>playlistsList = new ArrayList<Playlists>();

    RecyclerView myplaylistList;
    PlaylistAdapter playlistAdapter;
    private RecyclerView.LayoutManager layoutManager;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_playlist);

        myplaylistList = findViewById(R.id.recycle2);
        playlistAdapter = new PlaylistAdapter(PlaylistActivity.mplaylistlist);
        myplaylistList.setAdapter(playlistAdapter);
        myplaylistList.setLayoutManager(new LinearLayoutManager(this));

    }


    public void gobackhome(View view) {
        Intent intent = new Intent(this, MainInterfaceActivity.class);
        startActivity(intent);
    }

    public void gotomysongs(View view) {
        Intent intent = new Intent(this, MySongsActivity.class);
        startActivity(intent);
    }

    public void createplaylist(View view) {
        String playlistID = view.getContentDescription().toString();
        Playlist playlist = playlistCollection.searchById3(playlistID);
        mplaylistlist.add(playlist);
        Intent intent = new Intent(this, PlaylistActivity.class);
        startActivity(intent);
        Toast.makeText(this,"Playlist Created", Toast.LENGTH_SHORT).show();
    }
}