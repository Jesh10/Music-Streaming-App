package sg.edu.tp.musicstream;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.graphics.ColorSpace;
import android.os.Bundle;
import android.text.Editable;

import android.text.SpannableString;
import android.text.Spanned;
import android.text.TextWatcher;
import android.text.style.StyleSpan;
import android.text.style.UnderlineSpan;
import android.util.Log;

import android.view.Display;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;

import android.widget.ArrayAdapter;

import android.widget.EditText;

import android.widget.ListView;
import android.widget.SearchView;
import android.widget.TextView;


import java.util.ArrayList;
import java.util.List;


public class SearchActivity extends AppCompatActivity implements UsersAdapter.SelectedUser{

    Toolbar toolbar;
    RecyclerView recyclerView;
    UsersAdapter usersAdapter;

    List<Model> ModelList = new ArrayList<>();

    String [] names = {"Adele","Camilia Cabello","Dua Lipa","Coldplay","John Mayer","Ed Sheeran"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search);

        TextView textView = findViewById(R.id.textView22);
        String text = "Suggestions";
        SpannableString ss = new SpannableString(text);
        UnderlineSpan underlineSpan = new UnderlineSpan();
        ss.setSpan(underlineSpan, 0, 11, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        textView.setText(ss);
        recyclerView = findViewById(R.id.recyclerview);

        toolbar = findViewById(R.id.toolbar);

        this.getSupportActionBar().setTitle("");

        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.addItemDecoration(new DividerItemDecoration(this,DividerItemDecoration.VERTICAL));

        for(String s:names)
        {
            Model model = new Model(s);

            ModelList.add(model);
        }

        usersAdapter = new UsersAdapter(ModelList, this);

        recyclerView.setAdapter(usersAdapter);

    }

    @Override
    public void selectedUser(Model model) {

        startActivity(new Intent(SearchActivity.this, ArtistActivity.class).putExtra("data", model));

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu, menu);

        MenuItem menuItem = menu.findItem(R.id.search_view);

        SearchView searchView = (SearchView) menuItem.getActionView();

        searchView.setMaxWidth(Integer.MAX_VALUE);

        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener()
        {
            @Override
            public boolean onQueryTextSubmit(String query)
            {
                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText)
            {
                usersAdapter.getFilter().filter(newText);
                return true;
            }
        });
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item)
    {
        int id = item.getItemId();

        if(id == R.id.search_view)
        {
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    public void gobackhome (View view)
    {
        Intent intent = new Intent(this, MainInterfaceActivity.class);
        startActivity(intent);
    }
}